<?php 

namespace Rize\UriTemplate\Node;

/**
 * Description
 */
class Literal extends Abstraction
{

}