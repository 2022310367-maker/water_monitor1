# Google Protobuf Metadata Classes

## WARNING!

These classes are not intended for direct use - they exist only to support
the generated protobuf classes in src/
